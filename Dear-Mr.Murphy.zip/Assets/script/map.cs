﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class map : MonoBehaviour {

    public int row0;
    public int row1;
    public int row2;
    public int row3;
    public int row4;
    public int row5;
    public int row6;
    public int row7;
    public int row8;
    public int row9;
    public int row10;
    public int row11;
    public int row12;
    public int row13;
 
   

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
